select * from comments;
select * from messages;