$(document).ready(function(){
    $("#ninja1").click(function(){
        $("#ninja1").animate({opacity:0});
    })
    $("#ninja2").click(function(){
        $("#ninja2").animate({opacity:0});
    })
    $("#ninja3").click(function(){
        $("#ninja3").animate({opacity:0});
    })
    $("#ninja4").click(function(){
        $("#ninja4").animate({opacity:0});
    })
    $("#ninja5").click(function(){
        $("#ninja5").animate({opacity:0});
    })
    $("#ninja6").click(function(){
        $("#ninja6").animate({opacity:0});
    })
    $("#ninja7").click(function(){
        $("#ninja7").animate({opacity:0});
    })
    $("#ninja8").click(function(){
        $("#ninja8").animate({opacity:0});
    })

    $("#bt").click(function(){
        $(".container img").animate({opacity:1});
    })
});

